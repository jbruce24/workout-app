INSERT INTO "Movement" ("Name", "Function", "id") VALUES
('Assault Bike',	'Cardio',	'fb5ecf89-a5a8-49f2-9d8c-1a46290faad0'),
('Echo Bike',	'Cardio',	'd2403492-028a-45f8-b2f4-a8e5ddf7ee7b'),
('Concept2 Rower',	'Cardio',	'fd231d5d-2abf-4ced-852e-38da18776d7e'),
('Bike Erg',	'Cardio',	'dda8fa7c-f651-49e3-841c-b293d04b7d7f'),
('Concept2 Ski Erg',	'Cardio',	'34a463e4-9592-4224-a36f-268a655a4955'),
('Running',	'Cardio',	'79021713-f5c5-42a8-91c8-d701fad1bbf7'),
('Squat Clean',	'Weightlifting',	'4eccf836-50d8-4d3f-8025-bd3d1d929d47'),
('Air Squat',	'Functional Fitness',	'6a64698b-6bfe-41cb-842a-119889bb72bd'),
('Devil Press',	'Functional Fitness',	'7fa6a64e-7ba1-48f3-ba55-6fbb2884b6a1'),
('Pullup',	'Functional Fitness',	'2e5b2c99-8da1-4a35-a24b-55e4d3d9c021'),
('Pushup',	'Functional Fitness',	'ce6be58d-f120-4a30-930f-64ac6772ed7f'),
('Wall Walk',	'Functional Fitness',	'b5919699-efc1-43a0-9081-26a8772af1ae');
