INSERT INTO "Program" ("id", "nameId", "program", "creatorFName", "creatorLName") VALUES
('4f814730-f01e-49c0-8898-ca105eaad93c',	NULL,	'Invictus 3 Day Weightlifting',	NULL,	NULL),
('1e0c9a0d-53e7-41c7-8223-d9955106e6c5',	NULL,	'Year of the Engine',	NULL,	NULL),
('f0459fc3-0895-47d5-9ba3-7e6625a1c38b',	NULL,	'Crossfit',	'Dave',	'Coburn'),
('99938af2-9ef0-448a-ad3f-9166de89df6f',	NULL,	'Crossfit',	'Zach',	'Miller'),
('52bfd9c9-5f3c-475b-bae7-2df4f6af000f',	NULL,	'Crossfit',	'Jared',	'Bruce'),
('7ee4d1f9-1ef5-446e-b7ac-643d63f3d4a3',	NULL,	'Crossfit',	'Nikki',	'Pierce');
